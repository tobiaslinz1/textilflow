# Fränkischer Tag PDF Bot

Railway job for downloading the Bamberg e-paper PDF and sending it to Telegram.

## Required Railway variables

- `TELEGRAM_BOT_TOKEN`
- `EPAPER_USERNAME`
- `EPAPER_PASSWORD`

Optional:
- `TELEGRAM_CHAT_ID` — if omitted, the bot reads the newest message sent to it and discovers the chat ID.
- `EPAPER_LOGIN_URL` — defaults to `https://eplogin.fraenkischertag.de`
- `EDITION_NAME` — defaults to `Bamberg`
- `DEBUG_SCREENSHOT` — set to `1` to save a screenshot before failing.

## Railway

The program performs one run and exits. Configure the Railway service as a Cron Job.

Railway cron uses UTC. For 22:00 Germany, daylight-saving time must be considered. A fixed `0 20 * * *` corresponds to 22:00 during CEST; `0 21 * * *` corresponds to 22:00 during CET.

## First run

Send any message to the Telegram bot first. If `TELEGRAM_CHAT_ID` is absent, the program discovers the newest private chat via Telegram `getUpdates` and prints the numeric ID to the logs. Add that value as `TELEGRAM_CHAT_ID` afterward.

The e-paper UI can change. The script deliberately uses several text/role fallbacks, but the first authenticated run should be checked in Railway logs.
