import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const cfg = {
  token: process.env.TELEGRAM_BOT_TOKEN,
  chatId: process.env.TELEGRAM_CHAT_ID,
  username: process.env.EPAPER_USERNAME,
  password: process.env.EPAPER_PASSWORD,
  loginUrl: process.env.EPAPER_LOGIN_URL || "https://eplogin.fraenkischertag.de",
  edition: process.env.EDITION_NAME || "Bamberg",
};

function required(name, value) {
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
}
required("TELEGRAM_BOT_TOKEN", cfg.token);

async function telegram(method, body) {
  const res = await fetch(`https://api.telegram.org/bot${cfg.token}/${method}`, body);
  const data = await res.json();
  if (!data.ok) throw new Error(`Telegram ${method}: ${JSON.stringify(data)}`);
  return data.result;
}

async function discoverChatId() {
  if (cfg.chatId) return cfg.chatId;
  const updates = await telegram("getUpdates", {});
  const messages = updates.map(x => x.message).filter(Boolean).reverse();
  const privateMessage = messages.find(m => m.chat?.id);
  if (!privateMessage) {
    throw new Error("No Telegram chat found. Send the bot a message, then run again.");
  }
  console.log(`TELEGRAM_CHAT_ID=${privateMessage.chat.id}`);
  return String(privateMessage.chat.id);
}

async function sendText(chatId, text) {
  const fd = new FormData();
  fd.append("chat_id", chatId);
  fd.append("text", text);
  return telegram("sendMessage", { method: "POST", body: fd });
}

async function sendPdf(chatId, filePath, caption) {
  const bytes = await fs.readFile(filePath);
  const fd = new FormData();
  fd.append("chat_id", chatId);
  fd.append("caption", caption);
  fd.append("document", new Blob([bytes], { type: "application/pdf" }), path.basename(filePath));
  return telegram("sendDocument", { method: "POST", body: fd });
}

async function clickFirst(page, candidates) {
  for (const locator of candidates) {
    try {
      if (await locator.first().isVisible({ timeout: 1500 })) {
        await locator.first().click();
        return true;
      }
    } catch {}
  }
  return false;
}

async function run() {
  const chatId = await discoverChatId();

  if (!cfg.username || !cfg.password) {
    await sendText(chatId, "✅ Telegram-Verbindung funktioniert. E-Paper-Zugangsdaten fehlen noch in Railway.");
    console.log("Telegram test successful; EPAPER credentials not configured yet.");
    return;
  }

  const downloadDir = path.resolve("downloads");
  await fs.mkdir(downloadDir, { recursive: true });

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ acceptDownloads: true });
  const page = await context.newPage();

  try {
    console.log("Opening login page...");
    await page.goto(cfg.loginUrl, { waitUntil: "domcontentloaded", timeout: 60000 });

    // Cookie dialogs, if present.
    await clickFirst(page, [
      page.getByRole("button", { name: /akzeptieren|zustimmen|alle akzeptieren/i }),
      page.getByText(/alle akzeptieren/i)
    ]);

    // Login fields: use semantic and generic fallbacks.
    const userField = page.locator('input[type="email"], input[name*="user" i], input[name*="email" i], input[type="text"]').first();
    const passField = page.locator('input[type="password"]').first();
    await userField.fill(cfg.username);
    await passField.fill(cfg.password);

    const submitted = await clickFirst(page, [
      page.getByRole("button", { name: /anmelden|login|einloggen/i }),
      page.locator('button[type="submit"], input[type="submit"]')
    ]);
    if (!submitted) await passField.press("Enter");

    await page.waitForLoadState("domcontentloaded");
    await page.waitForTimeout(3000);

    // Select/open Bamberg edition if an edition chooser is shown.
    await clickFirst(page, [
      page.getByText(new RegExp(`Bamberg.*Fränkischer Tag|${cfg.edition}`, "i")),
      page.getByRole("link", { name: new RegExp(cfg.edition, "i") }),
      page.getByRole("button", { name: new RegExp(cfg.edition, "i") })
    ]);
    await page.waitForTimeout(3000);

    // Open menu if needed, then trigger "Ausgabe als PDF".
    await clickFirst(page, [
      page.getByRole("button", { name: /menü|menu|mehr/i }),
      page.locator('[aria-label*="menu" i], [aria-label*="menü" i]')
    ]);

    const pdfCandidates = [
      page.getByText(/Ausgabe als PDF/i),
      page.getByRole("link", { name: /Ausgabe als PDF/i }),
      page.getByRole("button", { name: /Ausgabe als PDF/i })
    ];

    let download = null;
    for (const locator of pdfCandidates) {
      try {
        if (await locator.first().isVisible({ timeout: 1500 })) {
          const pending = page.waitForEvent("download", { timeout: 60000 });
          await locator.first().click();
          download = await pending;
          break;
        }
      } catch {}
    }

    if (!download) {
      throw new Error('Could not find or trigger "Ausgabe als PDF". The reader UI may need selector adjustment.');
    }

    const today = new Intl.DateTimeFormat("de-DE", {
      timeZone: "Europe/Berlin", year: "numeric", month: "2-digit", day: "2-digit"
    }).format(new Date()).replaceAll(".", "-");
    const filePath = path.join(downloadDir, `Fraenkischer_Tag_Bamberg_${today}.pdf`);
    await download.saveAs(filePath);

    const stat = await fs.stat(filePath);
    if (stat.size < 10_000) throw new Error(`Downloaded PDF looks too small (${stat.size} bytes).`);

    await sendPdf(chatId, filePath, `📰 Fränkischer Tag – Bamberg – ${today}`);
    console.log(`Success: ${filePath} (${stat.size} bytes)`);
  } catch (err) {
    console.error(err);
    if (process.env.DEBUG_SCREENSHOT === "1") {
      try { await page.screenshot({ path: "debug.png", fullPage: true }); } catch {}
    }
    await sendText(chatId, `⚠️ Fränkischer-Tag-Download fehlgeschlagen:\n${String(err.message || err).slice(0, 1000)}`);
    throw err;
  } finally {
    await browser.close();
  }
}

run().catch(() => process.exit(1));
